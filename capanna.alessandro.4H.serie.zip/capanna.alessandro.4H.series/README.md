# Series

Data una stringa di cifre, creare tutte le sottostringhe contigue di lunghezza N

In questo esercizio, cercare di usare solo string e vettori.
Non usare Collezioni (List<>, etc)

Solo per collezionare il vettore di ritorno, volendo, si può usare una List<string> (vedi codice)


Ad esempio, 
- la stringa "49142" ha le seguenti serie di 3 cifre:
- "491", "914", "142"

- E le seguenti serie di 4 cifre:
- "4914", "9142"

In caso di 6 cifre deve sollevare una eccezione eseguendo la seguente riga di codice

 throw new ArgumentException();
